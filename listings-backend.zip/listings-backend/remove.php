<?php
    include('./databaseconnect.php');
    
    require_once('webflow_Api.php');
    
   // include("../webflow-php/vendor/autoload.php");
    
    $address=$_POST["address"];
    $row_id=$_POST["ids"];
    $type=$_POST['types'];
   // file_put_contents("post_types.txt","\n".print_r($_POST ,true),FILE_APPEND);
    $item_id='';
    
    if($type=='Active'){
   
        $get_id="select `webflow_Item_id` from `property` where `id`=".$row_id;
        $results = $conn->query($get_id);
        $row = $results->fetch_assoc();
        $item_id=$row['webflow_Item_id'];
    
        
        $query = "DELETE FROM `property` WHERE `id` = '".$row_id."'";
        $result = $conn->query($query);
        if($result !== false){
            //echo "success";
          }else {
            echo "Trasnfer failed    $conn->error";
          }
    }  
    else{
        $get_id="select `webflow_Item_id` from `soldlistings` where `id`=".$row_id;
        $results = $conn->query($get_id);
        $row = $results->fetch_assoc();
        $item_id=$row['webflow_Item_id'];
         
        $query = "DELETE FROM `soldlistings` WHERE `id` = '".$row_id."';";
        $result = $conn->query($query);
        if($result !== false) {
            //echo "success";        
          }
          else {
            //echo "Trasnfer failed    $conn->error";
          }
    }
     //file_put_contents("tem_id.txt","\n".print_r($item_id ,true),FILE_APPEND);
     if($item_id !='') {
          $delete_res=item_delete('DELETE',$item_id);
         // file_put_contents("delete_res.txt","\n".print_r($delete_res ,true),FILE_APPEND);
         echo "<script type='text/javascript'>alert('Success, Listing removed');
          window.location='loggedin.php';
          </script>";
     }
    
     
      /*$webflowAPI = $_SESSION['webflow_api'];
      //echo $webflowAPI."\n yay \n"; 
      $webflow = new \Webflow\Api($webflowAPI);
      $sites = $webflow->sites();
      //echo $sites[0]->_id;
      $findField=['name'=> $address];
      //echo $findField['name'];
      $collections = $webflow->collections($sites[0]->_id);
      $collectionID = 0;
      foreach( $collections as $value ) {
        if ($value->name == "Featured Listings"){
          $collectionID = $value->_id;
          echo("<script>console.log('found feat listing: ".$collectionID."');</script>");
        }
      }
      $itemID = $webflow->findOrCreateItemByName($collectionID,$findField);
     // echo "here\n".print_r($itemID);
      echo "here2\n".print_r($itemID[0]);
      //echo "here3\n".print_r($itemID->_id);
      $webflow->removeItem($collectionID, $itemID->_id);*/  
      
      
   
?>