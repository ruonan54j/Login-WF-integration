<?php

include('databaseconnect.php');
require_once('webflow_Api.php');
require("../webflow-php/vendor/autoload.php");

$image='';
$images = [];
$imagesWF = [];

 $fileLength=$_POST['file_length'];

for ($i = 0; $i <= $fileLength; $i++){
    $fileName = $_FILES['myfile'.$i]['name'];

  if ($fileName != ""){
    $currentDir = 'https://castlelab.ca/LoginWF_t/listings-backend/';
    $uploadDirectory = 'uploaded_images//';

    $errors = []; // Store all foreseen and unforseen errors here

    $fileExtensions = ['jpeg','jpg','png']; // Get all the file extensions

    $images[] = "uploaded_images/".$fileName;
    $imagesWF[] = $currentDir."uploaded_images/".$fileName;

    $fileSize = $_FILES['myfile'.$i]['size'];
    $fileTmpName  = $_FILES['myfile'.$i]['tmp_name'];
    $fileType = $_FILES['myfile'.$i]['type'];
    // $tempExt =end(explode('.',$_FILES['myfile'.$i]['name']));
    //$fileExtension = strtolower($tempExt);
    //echo "</br>";
     $uploadPath =  $uploadDirectory . basename($fileName); 

     $didUpload = move_uploaded_file($fileTmpName, $uploadPath);
     
    if ($didUpload) {
        echo ( "<script> console.log('The file " . basename($fileName) . " has been uploaded')</script>");
    } else {
        echo "An error occurred somewhere. Try again or contact the admin";
    }
  }
}
  // echo "<pre>";
  //print_r($imagesWF);
  //die;
  $floorplan=$image1=$image2=$image3=$image4=$image5=$image6=$image7=$image8=$image9=$floorplans='';

 if(isset($imagesWF[0])){
    $floorplan = $imagesWF[0];
 }
 if(isset($imagesWF[1])){
    $image1=$imagesWF[1];
 }
 if(isset($imagesWF[2])){
    $image2=$imagesWF[2];
 }
 if(isset($imagesWF[3])){
    $image3=$imagesWF[3];
 }
 if(isset($imagesWF[4])){
    $image4=$imagesWF[4];
 }
 if(isset($imagesWF[5])){
    $image5=$imagesWF[5];
 }
 if(isset($imagesWF[6])){
    $image6=$imagesWF[6];
 }if(isset($imagesWF[7])){
    $image7=$imagesWF[7];
 }
 if(isset($imagesWF[8])){
    $image8=$imagesWF[8];
 }
 if(isset($imagesWF[9])){
    $image9=$imagesWF[9];
 }
 if(isset($imagesWF[10])){
    $floorplans=$imagesWF[10];
 }


  $mlsid = $_POST["mlsid"];
   $description = str_replace ('"'," ",$_POST["description"]);
 
  $price = $_POST["price"];
  $streetaddress = str_replace ('"'," ",$_POST["street_address"]);
  $postalCode = $_POST["postal_code"];
  
  
  $proptype = $_POST["building_type"];
  $province = $_POST["province"];
  $locality = $_POST["locality"];
  $beds = $_POST["beds"];
  $bathrooms = $_POST["bathrooms"];
  $size = $_POST["size"];
   
  $sold = false;
  if(isset($_POST["active_sold"])){
   if($_POST["active_sold"] == true){
     $sold = true;
   }else{
       $sold = false;
   }
  }
 
  if(isset($images[0])){
  $image = $images[0];
  }
  $images =implode(",",$images);

  $query= "";
   //echo "IMAGE LIST: ".$image;
   //echo "test";
    $flag1=false;
    if ($sold == false) {     
       $query = "INSERT INTO `soldlistings` (`mlsid`, `image`, `images`, `description`, `price`, `streetaddress`, `addressLocality`, `addressProvince`, `postalCode`, `beds`, `bathrooms`, `propsize`, `proptype`, `Sold`) VALUES ('".$mlsid."', '".$image."', '".$images."', '".$description."', '".$price."', '".$streetaddress."', '".$locality."', '".$province."', '".$postalCode."', '".$beds."', '".$bathrooms."', '".$size."', '".$proptype."', '0')";
    }
   else{
      $flag1=true;
      $query = "INSERT INTO `property`(`mlsid`, `image`, `images`, `description`, `price`, `streetaddress`, `addressLocality`, `addressProvince`, `postalCode`, `beds`, `bathrooms`, `propsize`, `proptype`, `Sold`) VALUES ('".$mlsid."', '".$image."', '".$images."', '".$description."', '".$price."', '".$streetaddress."', '".$locality."', '".$province."', '".$postalCode."', '".$beds."', '".$bathrooms."', '".$size."', '".$proptype."', '".$sold."')";
    }
   
    $result = $conn->query($query);
   //====================================//
    //String json body for cms webflow
    if($sold == 1){
      $sold='false';
    }else{
      $sold='true';
    }
    $fields =' {
               "fields": {
                      "name" : "'.$streetaddress.'",
                      "_archived":false,
                      "_draft": false,
                      "neighbourhood" : "'.$locality.'",
                      "postal-code" : "'.$postalCode.'",
                      "sale-price" : "'.$price.'",
                      "mls-id" : "'.$mlsid.'",
                      "property-type" : "'.$proptype.'",
                      "number-of-rooms" : "'.$beds.'",
                      "number-of-baths" : "'.$bathrooms.'",
                      "square-feet" : "'.$size.'",
                      "property-description" : "'.$description.'",
                      "available" : "'.$sold.'",
                      "floorplan" : "'.$floorplan.'",
                      "image-1" : "'.$image1.'",
                      "image-2" : "'.$image2.'",
                      "image-3" : "'.$image3.'",
                      "image-4" : "'.$image4.'",
                      "image-5" : "'.$image5.'",
                      "image-6" : "'.$image6.'",
                      "image-7" : "'.$image7.'",
                      "image-8" : "'.$image8.'",
                      "image-9" : "'.$image9.'",
                      "floorplans" : "'.$floorplans.'"
                  }
              }';
    //=====================================//
   if($result !== false) {
        $last_id = $conn->insert_id;
       //call insert item in cms webflow api file
        $get_item = item_insert('POST',$fields);

        $error_mes='';
        if(isset($get_item['msg'])) {
         $error_mes=$get_item['msg'];
        }

        if($error_mes !='') {
          ?>

           <script type='text/javascript'>
            alert('Transfer failed : please contact technical support');       
             window.location='loggedin.php';  
           </script>

        <?php

          } elseif ($flag1==true) {        
          $update="UPDATE `property` SET `webflow_Item_id`='".$get_item['_id']."',`webflow_status`='".true."' WHERE id=".$last_id;
          $update_result = $conn->query($update);  
          } else{

            $update="UPDATE `soldlistings` SET `webflow_Item_id`='".$get_item['_id']."',`webflow_status`='".true."' WHERE id=".$last_id;
            $update_result = $conn->query($update); 
          }  

      if($flag1==true) {
        ?>

          <script type='text/javascript'>
            alert('Transfer Successful : Active Property');
             window.location='loggedin.php'
           </script>';

      <?php   

      }else {

      ?>
      
         <script type='text/javascript'>
            alert('Transfer Successful : Sold Property');
            window.location='loggedin.php';
           </script>
       
      <?php     
      }        
    } 
?>